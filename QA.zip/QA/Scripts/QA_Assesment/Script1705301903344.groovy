import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser(GlobalVariable.payment_page)

//Verify the email address form
WebUI.verifyElementPresent(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-email_address-65a4983a11492"]), 15)

//Set text for email
WebUI.setText(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-email_address-65a4983a11492"]), "random@qa.com")

//Verify and set text for first name and last name
WebUI.verifyElementPresent(findTestObject('Object Repository/Relative XPath/elementByName',[('element'):"first_name"]), 15)

WebUI.verifyElementPresent(findTestObject('Object Repository/Relative XPath/elementByName',[('element'):"last_name"]), 15)

WebUI.setText(findTestObject('Object Repository/Relative XPath/elementByName',[('element'):"first_name"]), "first_name")

WebUI.setText(findTestObject('Object Repository/Relative XPath/elementByName',[('element'):"last_name"]), "last_name")

//Verify card number, expiration date, cvc and zip
WebUI.verifyElementPresent(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-card_number-65a4983a11492"]), 15)

WebUI.verifyElementPresent(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-card_expiration_date-65a4983a11492"]), 15)

WebUI.verifyElementPresent(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-card_cvc-65a4983a11492"]), 15)

WebUI.verifyElementPresent(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-card_zip_code-65a4983a11492"]), 15)

//Insert value to card number, exp date, cvc, and zip

//get failed in here as it needs to be parsed to integer and the param of settext is string

WebUI.setText(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-card_number-65a4983a11492"]), "4242 4242 4242 4242")

WebUI.setText(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-card_expiration_date-65a4983a11492"]), "1230")

WebUI.setText(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-card_cvc-65a4983a11492"]), "1234")

WebUI.setText(findTestObject('Object Repository/Relative XPath/elementById',[('element'):"payment-page-card_zip_code-65a4983a11492"]), "12345")

WebUI.click(findTestObject('Object Repository/Relative XPath/buttonSubmit'))






